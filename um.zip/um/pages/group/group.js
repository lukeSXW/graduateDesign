// pages/group/group.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cate_title: [{
        id: 1,
        title: '设计',
        req: 'group/design',
        font: '50rpx',
        color: 'lightgrey'
      },
      {
        id: 2,
        title: '摄影',
        req: 'group/Photography',
        font: '50rpx',
        color: 'lightgrey'
      },
      {
        id: 3,
        title: '小哥哥',
        req: 'group/boy',
        font: '50rpx',
        color: 'lightgrey'
      },
      {
        id: 4,
        title: '小姐姐',
        req: 'group/girl',
        font: '50rpx',
        color: 'lightgrey'
      },
      {
        id: 5,
        title: '音乐',
        req: 'group/music',
        font: '50rpx',
        color: 'lightgrey'
      },
      {
        id: 6,
        title: '舞蹈',
        req: 'group/dance',
        font: '50rpx',
        color: 'lightgrey'
      },
    ],
    footer: {
      "share": "https://www.htmlstudio.top/imgs/others/share",
      "comment": "https://www.htmlstudio.top/imgs/others/comment",
      "delete_src": "https://www.htmlstudio.top/imgs/others/error"
    }
  },

  delete_msg: function() {
    wx.showModal({
      title: '特权操作请联系管理员',
      showCancel: false
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this
    that.title_select({
      currentTarget: {
        id: 1
      }
    })
  },

  onstar: function(event) {
    if (!wx.getStorageSync('uid')) {
      wx.navigateTo({
        url: '../per_regist/per_regist',
      })
    } else {
      if (event.currentTarget.dataset.openid == wx.getStorageSync('openid')) {
        wx.showToast({
          title: '不能关注自己哦',
        })
      } else {
        event.currentTarget.dataset.my_id = wx.getStorageSync('openid')
        wx.request({
          url: 'https://www.htmlstudio.top/onstar',
          data: event.currentTarget.dataset,
          success(res) {
            wx.showToast({
              title: res.data,
            })
          }
        })
      }
    }
  },

  post_msg: function() {
    wx.navigateTo({
      url: '../post_msg/post_msg',
    })
  },

  comment: function(event) {
    wx.navigateTo({
      url: '../comment_page/comment_page?id=' + event.currentTarget.id
    })
  },

  good_status: function(event) {
    let id = event.currentTarget.id
    let cate = event.currentTarget.dataset.cate
    let per_message = this.data.per_message
    per_message.forEach(value => {
      if (value.id == event.currentTarget.id) {
        value.goodimg = value.goodimg == 'https://www.htmlstudio.top/imgs/others/good' ? 'https://www.htmlstudio.top/imgs/others/good_1' : 'https://www.htmlstudio.top/imgs/others/good'
        if (value.goodimg == 'https://www.htmlstudio.top/imgs/others/good_1') {
          wx.request({
            url: 'https://www.htmlstudio.top/Editgood',
            data: {
              cate: cate,
              id: id,
              add: true
            },
            success(res) {
              console.log(res)
            }
          })
          value.good_num += 1
        } else {
          wx.request({
            url: 'https://www.htmlstudio.top/Editgood',
            data: {
              cate: cate,
              id: id,
              add: false
            },
            success(res) {
              console.log(res)
            }
          })
          value.good_num -= 1
        }
      }
    })
    this.setData({
      per_message
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  M2detail: function(event) {
    wx.navigateTo({
      url: `../detail_page/detail_page?id=${event.currentTarget.id}&girl=${this.data.female_select}`
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {


  },
  title_select: function(event) {
    let that = this
    let id = event.currentTarget.id
    let arr = this.data.cate_title
    arr.forEach(function(value, index, arr) {
      if (id - 1 != index) {
        value.font = '50rpx'
        value.color = 'lightgrey'
      } else {
        value.font = '55rpx'
        value.color = 'black'
      }
    })
    let item = arr.filter(function(value, index, arr) {
      return value.id == event.currentTarget.id
    })
    let female_select
    if (item[0].req == 'group/girl' || item[0].req == 'group/music' || item[0].req == 'group/dance') {
      female_select = true
    } else {
      female_select = false
    }
    wx.request({
      url: 'https://www.htmlstudio.top/' + item[0].req,
      method: 'post',
      success(res) {
        that.setData({
          per_message: res.data.msg
        })
      }
    })

    this.setData({
      cate_title: arr,
      female_select
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})