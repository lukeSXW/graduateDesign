// pages/stars/stars.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stars:[]
  },

  chat:function(event){
    wx.navigateTo({
      url: `../chat/chat?openid=${event.currentTarget.dataset.openid}&&avatar=${event.currentTarget.dataset.avatar}`,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    let that =this
    if(options.msg=='star'){
      wx.request({
        url: 'https://www.htmlstudio.top/checkstar',
        data: {
          id: options.id
        },
        success(res) {
          that.setData({
            stars:res.data
          })
        }
      })
    }
  },

  canclestar:function(event){
    let that = this
    wx.request({
      url: 'https://www.htmlstudio.top/canclestar',
      data:{
        star_id: event.currentTarget.dataset.openid,

        my_id:wx.getStorageSync('openid')
      },
      success(res){
        that.setData({
          stars:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})