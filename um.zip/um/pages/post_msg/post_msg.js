// pages/post_msg/post_msg.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [{
        name: 'design',
        value: '设计',
        checked: 'true'
      },
      {
        name: 'Photography',
        value: '摄影',

      },
      {
        name: 'music',
        value: '音乐'
      },
      {
        name: 'dance',
        value: '舞蹈'
      },
    ],
    show: true,
    content_img: '',
    show_1: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let detail = {
      nickName: wx.getStorageSync('nickname'),
      avatar: wx.getStorageSync('avatar')
    }
    this.setData({
      detail
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  add_photo: function() {
    let that = this
    wx.chooseImage({
      success: function(res) {
        that.setData({
          content_img: res.tempFilePaths,
          show: !that.data.show
        })
      },
    })
  },

  add_photo_1: function() {
    let that = this
    wx.chooseImage({
      success: function(res) {
        that.setData({
          detail_img: res.tempFilePaths,
          show_1: !that.data.show_1
        })
      },
    })
  },

  submit_msg: function(event) {
    let that = this
    let required = Object.values(event.detail.value).some(value => {
      return value == ''
    })
    if (required) {
      wx.showToast({
        title: '缺少必填项',
      })
    } else {
      event.detail.value.avatar = wx.getStorageSync('avatar')
      event.detail.value.nickName = wx.getStorageSync('nickname')
      event.detail.value.openid = wx.getStorageSync('openid')
      wx.request({
        url: 'https://www.htmlstudio.top/upload_msg',
        data: event.detail.value,
        success(res){
          
        }
      })
    }
    wx.switchTab({
      url: '../group/group',
    })
  },


  check_content: function(event) {
    let that = this
    let url = event.detail.value
    let reg = /^((ht|f)tps?):\/\/[\w\-]+(\.[\w\-]+)+([\w\-.,@?^=%&:\/~+#]*[\w\-@?^=%&\/~+#])?$/;
    if (!reg.test(url)) {
      wx.showToast({
        title: 'url格式不正确',
        icon: 'none'
      })
    } else {
      that.setData({
        content_img: url,
        show: !that.data.show
      })
    }
  },

  check_detail: function(event) {
    let that = this
    let url = event.detail.value
    let reg = /^((ht|f)tps?):\/\/[\w\-]+(\.[\w\-]+)+([\w\-.,@?^=%&:\/~+#]*[\w\-@?^=%&\/~+#])?$/;
    if (!reg.test(url)) {
      wx.showToast({
        title: 'url格式不正确',
        icon: 'none'
      })
    } else {
      that.setData({
        detail_img: url,
        show_1: !that.data.show_1
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})