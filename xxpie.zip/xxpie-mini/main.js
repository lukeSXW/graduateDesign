import Vue from 'vue'
import App from './App'
import $http from '@/common/request/requestConfig';
import navBar from "@/components/navBar";

Vue.config.productionTip = false
Vue.prototype.$http = $http;

App.mpType = 'app'
Vue.component("nav-bar", navBar);
const app = new Vue({
    ...App
})
app.$mount()
