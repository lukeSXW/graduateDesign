<template>
	<view class="main">
		<!-- <view class="nav">
			<image class="nav-return" src="../../static/albumsDetail/back.png" @click="lastPage" />
			<text style="text-align: center;">添加标签</text>
		</view> -->

		<view class="lebelEdit">
			<view v-for="item in lebalArr" class="singinLebal" :key="item.id" :style="{background:item.back,color:item.color}">
				<text>{{item.title}}</text>

				<text style="margin-left: 20rpx;" @click="deleteLabel(item.title)">x</text>
			</view>
			<input style="width: 200rpx;height: 50rpx;" placeholder="新建标签" @blur="diy_lebal" v-model="diyValue"/>
		</view>

		<view class="allLebals">
			<view style="padding: 24rpx;font-family:PingFangSC-Regular,PingFang SC;font-weight:400;color:rgba(102,102,102,1);">
				所有标签
			</view>

			<view style="display: flex;flex-direction: row;flex-wrap: wrap;padding:24rpx;width: 100%;height: 700rpx;align-content: start;">
				<view v-for="item in lebels" :key="item.id" :style="{background:item.back,color:item.color}" @click="addlebal(item.id)"
				 class="singinLebal">
					{{item.title}}
				</view>
			</view>

			<view style="display: flex;flex-direction: row;justify-content: space-around;">
				<view class="btn">
					取消
				</view>
				<view class="btn" style="color: white;background:linear-gradient(270deg,rgba(250,69,69,1) 0%,rgba(255,102,20,1) 100%);">
					保存
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				lebels: [{
						id: 1,
						title: '公司年会'
					},
					{
						id: 2,
						title: '长沙分公司'
					},
					{
						id: 3,
						title: '1'
					},
					{
						id: 4,
						title: '2'
					},
					{
						id: 5,
						title: '深圳分公司'
					},
					{
						id: 6,
						title: '深圳分公司'
					},
					{
						id: 7,
						title: '深圳分公司'
					},
				],
				lebalArr: [],
				diyValue:''
			}
		},
		methods: {
			lastPage() {
				uni.navigateBack({
					delta: 1
				});
			},
			addlebal(id) {
				let lebal = this.lebels.find(value => {
					return value.id == id
				})
				lebal.color = '#FF4E28'
				lebal.back = 'rgba(255,243,240,1)'
				if (this.lebalArr.some(value => {
						return value.id == lebal.id
					})) {
					uni.showToast({
						title: '标签已存在'
					})
				} else {
					this.lebalArr.push(lebal)
				}
			},
			diy_lebal(e){
					let value = e.target.value.trim()
					if(value){
						this.lebalArr.push({
							id:this.lebalArr.length,
							title:value,
							color:'#FF4E28',
							back:'rgba(255,243,240,1)'
						})
						this.diyValue=''
					}else{
						uni.showToast({
							title:'标签不能为空'
						})
					}					
			},
			deleteLabel(title) {
				this.lebalArr.forEach((value, index) => {
					if (value.title == title)
						this.lebalArr.splice(index, 1)
				})
				this.lebels.forEach(value => {
					if (value.title == title) {
						value.back = undefined
						value.color = undefined
					}
				})
			}
		}
	}
</script>

<style>
	.main {
		width: 750rpx;
		height: 1335rpx;
		background: rgba(242, 242, 242, 1);
		display: flex;
		flex-direction: column;
	}

	.nav {
		text-align: center;
		padding-top: 60rpx;
		height: 120rpx;
		font-size: 34upx;
		color: #333333;
		background-color: white;
		position: sticky;
		top: 0;
		left: 0;
		z-index: 1;
	}

	.nav-return {
		float: left;
		margin-top: 10rpx;
		width: 35rpx;
		height: 35rpx;
	}

	.lebelEdit {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		padding: 25rpx;
		width: 750rpx;
		/* height: fit-content; */
		min-height: 110rpx;
		background: rgba(255, 255, 255, 1);
		margin-bottom: 20rpx;
	}

	.allLebals {
		width: 750rpx;
		height: 1076rpx;
		background: rgba(255, 255, 255, 1);
	}

	.singinLebal {
		width: fit-content;
		height: fit-content;
		color: #666666;
		padding: 8rpx 20rpx;
		margin-bottom: 30rpx;
		margin-right: 40rpx;
		background: rgba(242, 242, 242, 1);
		font-size: 28rpx;
		font-family: PingFangSC-Regular, PingFang SC;
		font-weight: 400;
		text-align: center;
	}

	.btn {
		width: 300rpx;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFangSC-Medium, PingFang SC;
		font-weight: 500;
		background: rgba(242, 242, 242, 1);
		border-radius: 45rpx;
	}
</style>
