<template>
	<view>
		<view class="header">
			<image src="../../static/albumsDetail/back.png" style="position: fixed;width: 20rpx;height: 36rpx;"></image>
			<view style="width: 100%;">
				<view  style="background-color: rgba(242,242,242,1);font-size: 18rpx;line-height: 40rpx;margin-right: 12rpx;text-align: center;display: inline-block;width: 40rpx;height: 40rpx;">
					ALL
				</view>  
				<text style="margin-right: 12rpx;">全部图库</text>
				<image @click="selectAlbums" src="../../static/albumsDetail/downTrangle.png" style="width: 16rpx;height: 8rpx;margin-bottom: 8rpx;"></image>
			</view>
		</view>
		
		<view class="selectPanel" v-show="selectPanel">
			
			<view v-for="item in selections" :key="item.id" style="display: flex;flex-direction: row;border-bottom: 1rpx solid #E5E5E5;;padding: 40rpx 24rpx;">
				<view :style="{background:item.back,color:item.f_color}" style="font-size: 18rpx;line-height: 40rpx;margin-right: 12rpx;text-align: center;display: inline-block;background:rgba(242,242,242,1);width: 40rpx;height: 40rpx;">
					{{item.icon}}
				</view>
				<view >
					{{item.title}}
				</view>
				<image @click="changestatus(item.id)" :src="item.src" style="width: 44rpx;height: 44rpx;"></image>
			</view>
			
		</view>
		<view class="input_area">
			<image src="../../static/albumsDetail/search.png" style="width: 40rpx;height: 40rpx;position: fixed;margin: 20rpx 24rpx;"></image>
			<input type="text" placeholder="查找图片/视频" style="color:#999999;width: 702rpx;height: 80rpx;background:rgba(242,242,242,1);border-radius:40rpx;margin: 0 auto;padding:0rpx 100rpx 0rpx 80rpx;"/>
			<image  src="../../static/albumsDetail/image_icon.png" style="width: 44rpx;height: 36rpx;position: fixed;margin: 22rpx 24rpx 20rpx 620rpx;"></image>
		</view>
		
		<!-- <view class="message" v-if="no_search">
			<view v-for="item in msg" :key="item.id" >
				<view  style="margin-bottom: 20rpx;width:60rpx;height:42rpx;font-size:30rpx;font-family:PingFangSC-Semibold,PingFang SC;font-weight:600;color:rgba(51,51,51,1);line-height:42px;">
					{{item.title}}
				</view>
				<view style="margin-bottom: 60rpx;font-size:28rpx;font-family:PingFangSC-Regular,PingFang SC;font-weight:400;color:rgba(153,153,153,1);">
					{{item.selection}}
				</view>
			</view>
		</view> -->
		
		<view class="message" >	
		
			<view >
				<view  style="display: inline-block;margin-bottom: 20rpx;height:42rpx;font-size:30rpx;font-family:PingFangSC-Semibold,PingFang SC;font-weight:600;color:rgba(51,51,51,1);line-height:42px;">
					<text>人物</text>	
					<text style="margin-left: 565rpx;font-size:26rpx;font-family:PingFangSC-Regular,PingFang SC;font-weight:400;color:rgba(153,153,153,1);">全部></text>
				</view>
				<view class="avatar_area">
					<image style="width: 120rpx;height: 120rpx;border-radius: 50%;margin-right: 20rpx;white-space: nowrap;" :src="item.src" v-for="item in avatars" :key="item.id" ></image>
				</view>
			</view>
			
			<view >
				<view  style="display: inline-block;margin-bottom: 20rpx;height:42rpx;font-size:30rpx;font-family:PingFangSC-Semibold,PingFang SC;font-weight:600;color:rgba(51,51,51,1);line-height:42px;">
					<text>标签</text>	
					<text style="margin-left: 565rpx;font-size:26rpx;font-family:PingFangSC-Regular,PingFang SC;font-weight:400;color:rgba(153,153,153,1);">全部></text>
				</view>
				<view class="lebals_area">
					<view style="margin-right: 20rpx;background:rgba(242,242,242,1);width: fit-content;height: 56rpx;padding: 8rpx 20rpx;" v-for="item in lebals" :key="item.id">{{item.title}}</view>
				</view>
			</view>
			
			
			<view >
				<view  style="display: inline-block;margin-bottom: 20rpx;height:42rpx;font-size:30rpx;font-family:PingFangSC-Semibold,PingFang SC;font-weight:600;color:rgba(51,51,51,1);line-height:42px;">
					<text>收藏</text>	
					<text style="margin-left: 565rpx;font-size:26rpx;font-family:PingFangSC-Regular,PingFang SC;font-weight:400;color:rgba(153,153,153,1);">全部></text>
				</view>
				<view class="avatar_area">
					<image style="width: 120rpx;height: 120rpx;margin-right: 20rpx;white-space: nowrap;" :src="item.src" v-for="item in avatars" :key="item.id"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				selectPanel:false,
				selections:[
					{
						id:1,
						icon:'ALL',
						title:"全部空间",
						back:'rgba(242,242,242,1)',
						f_color:'black',
						src:'../../static/albumsDetail/waitphoto.png'
					},
					{
						id:2,
						icon:'教',
						title:"长沙市教育局",
						back:'rgba(55,134,248,1)',
						f_color:'white',
						src:'../../static/albumsDetail/waitphoto.png'
					},
					{
						id:3,
						icon:'为',
						title:"长沙为百科技公司",
						back:'rgba(51,51,51,1)',
						f_color:'white',
						src:'../../static/albumsDetail/waitphoto.png'
					},
				],
				lebals:[
					{
						id:1,
						title:'部门年会'
					},
					{
						id:2,
						title:'公司年会'
					},
					{
						id:3,
						title:'长沙分公司'
					},
					{
						id:4,
						title:'深圳分公司'
					},
				],
				avatars:[
					{id:1,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:2,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:3,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:4,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:5,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:6,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					},
					{id:7,
					src:'https://www.htmlstudio.top/imgs/home_pic/music/avatar'
					}					
				],
				msg:[
					{
						id:1,
						title:'人物',
						selection:'暂时未识别到人物~'
					},
					{
						id:2,
						title:'标签',
						selection:'暂未创建标签，点击去创建>>'
					},
					{
						id:3,
						title:'收藏',
						selection:'暂时还没有收藏的文件哦~'
					},
				]
			}
		},
		methods: {
			selectAlbums(){
				this.selectPanel=!this.selectPanel
			},
			changestatus(id){
				this.selections.forEach(value=>{
					if(value.id==id)
						value.src=value.src== '../../static/albumsDetail/selected.png' ?
								'../../static/albumsDetail/waitphoto.png' : '../../static/albumsDetail/selected.png'
				})
			}
		}
	}
</script>

<style>
	.avatar_area{
		display: flex;
		flex-direction: row;
		overflow-x: auto;
		margin-top: 20rpx;
	}
	
	.lebals_area{
		display: flex;
		flex-direction: row;
		overflow-x: auto;
		margin-top: 20rpx;
	}

	.selectPanel{
		display: flex;
		flex-direction: column;
		width:750rpx;
		height:422rpx;
		background:rgba(255,255,255,1);
		position: fixed;
		top: 88rpx;
		z-index: 1;
	}
	.header{
		display: flex;
		flex-direction: row;
		padding: 40rpx 25rpx 25rpx 25rpx;
		width: 750rpx;
		height: 88rpx;
		background:rgba(255,255,255,1);
		text-align: center;
	}
	.input_area{
		padding: 20rpx 24rpx;
		display: flex;
		flex-direction: row;
		width:750rpx;
		height:120rpx;
		background:rgba(255,255,255,1);
	}
	.message{
		width:750px;
		height:1085rpx;
		background:rgba(255,255,255,1);
		padding: 50rpx 24rpx;
		display: flex;
		flex-direction: column;
	}
	


</style>
