<template>
	<view class='main'>
		<view class="nav">
			<image class="nav-return" src="../../static/albumsDetail/back.png" @click="lastPage" />
			<view style="width: fit-content;margin-left: 370rpx;">
				<image src="../../static/albumsDetail/search.png" @click="m2allAlbums" class="header_img"></image>
				<image src="../../static/albumsDetail/check.png" class="header_img"></image>
			</view>
		</view>

		<view class="perInfo">
			<view>
				<text style="font-weight: bold;">2020-03-17</text>
				<image src="../../static/albumsDetail/search.png" style="margin-top:12rpx;margin-right: 12rpx;width:24rpx;height:24rpx;margin-left:404rpx;border-radius: 50%;"></image>
				<text style="font-weight: bold;">哈雷娜</text>
			</view>
			<view style="display: block;margin-top: 20rpx;">
				<text style="color: #666666;">红黄蓝长沙高开区分校</text>
			</view>
		</view>

		<view class="selectTitle" v-if="status_1==1">
			<text style="display: inline-block;width: 126rpx;height: 40rpx;margin-right:80rpx;font-weight:500;" :style="{color:item.color}"
			 :data-title='item.title' v-for="item in mediaArr" :key="item.id" @click="mediaSelect">{{item.title}}(220)</text>
			<view style="height: 99rpx;width: 204rpx;margin-left: 90rpx;">
				<image src="../../static/albumsDetail/filter.png" style="width: 36rpx;height: 36rpx;"></image>
				<text style="margin-left: 8rpx;" @click="showSelection" :style="{color:selectionColor}">标签筛选</text>
			</view>
		</view>


		<view class="selectTitle" v-if="status_1==2">
			<text style="flex: 1;text-align: center;color: #FF4E28;" @click="selected('all')">全选</text>
			<text style="flex: 3;text-align: center;color: #333333;font-family:PingFangSC-Semibold,PingFang SC;font-weight:600;">已选中{{selected_numbers}}</text>
			<text style="flex: 1;text-align: center;color: #FF4E28;" @click="cancleSelect">取消</text>
		</view>

		<view class="bottomTab" v-if="status_1==2">
			<view class="items" @click="icon_choose(item.title)" v-for="item in tabbars" :key="item.id">
				<view style="display: inline-block;height: 48rpx;width:48rpx;margin: 0 auto;">
					<image :src="item.src"></image>
				</view>
				<text>{{item.title}}</text>
			</view>
		</view>

		<view class="labelPanel" v-show="labelShow">
			<view class="labels">
				<text>无标签文件</text>
				<text>部门年会</text>
				<text>长沙分公司</text>
				<text>深圳分公司</text>
				<text>深圳分公司深圳分公司</text>
			</view>
			<view class="btn">
				确定
			</view>
		</view>

		<view class="photoArea" v-if="mediaStatus=='photo'">
			<image v-show="empty_status" src="../../static/albumsDetail/videoEmpty.png" style="width: 300rpx;height: 400rpx;position: absolute;top:0;left:0;bottom:0;right: 0;margin: auto;"></image>
			<view class="imgs" @longtap="photoSelect" @click="selected(item.id)" v-for="item in photos" :key="item.id">
				<image :src="item.src">
				</image>
				<image v-show="selectShow" id="item.id" :src="item.src_1" style="position: absolute;top: 15rpx;right: 15rpx;width: 44rpx;height: 44rpx;"></image>
			</view>
		</view>

		<view class="photoArea" v-if="mediaStatus=='video'">
			<image v-show="empty_status" src="../../static/albumsDetail/videoEmpty.png" style="width: 300rpx;height: 400rpx;position: absolute;top:0;left:0;bottom:0;right: 0;margin: auto;"></image>
			<view class="imgs" @longtap="videoSelect" @click="selected(item.id)" v-for="item in videos" :key="item.id">
				<image :src="item.src">
				</image>
				<image v-show="selectShow" id="item.id" :src="item.src_1" style="position: absolute;top: 15rpx;right: 15rpx;width: 44rpx;height: 44rpx;"></image>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				empty_status: false,
				mediaStatus: 'photo',
				mediaArr: [{
					id: 1,
					title: '图片',
					color: '#FF4E28'
				}, {
					id: 2,
					title: '视频',
					color: '#333333'
				}],
				tabbars: [{
						id: 1,
						src: '../../static/albumsDetail/add.png',
						title: '添加到'
					},
					{
						id: 2,
						src: '../../static/albumsDetail/ai.png',
						title: 'AI修图'
					},
					{
						id: 3,
						src: '../../static/albumsDetail/share_1.png',
						title: '分享'
					},
					{
						id: 4,
						src: '../../static/albumsDetail/label.png',
						title: '标签'
					},
					{
						id: 5,
						src: '../../static/albumsDetail/more.png',
						title: '更多'
					},

				],
				status_1: 1,
				selected_numbers: 0,
				photos: [{
						id: 1,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 2,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 3,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 4,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 5,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 6,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 7,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 8,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 9,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 10,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 11,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 12,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 13,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 14,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 15,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 16,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 17,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 18,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 19,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 20,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 21,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 22,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 23,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 24,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					},
					{
						id: 25,
						src: `https://www.htmlstudio.top/imgs/others/beauty_1`,
						src_1: `../../static/albumsDetail/waitphoto.png`
					}
				],
				videos: [{
						id: 1,
						src: 'https://www.htmlstudio.top/imgs/others/beauty_3'
					},
					{
						id: 2,
						src: 'https://www.htmlstudio.top/imgs/others/beauty_3'
					},
					{
						id: 3,
						src: 'https://www.htmlstudio.top/imgs/others/beauty_3'
					},
					{
						id: 4,
						src: 'https://www.htmlstudio.top/imgs/others/beauty_3'
					},
					{
						id: 5,
						src: 'https://www.htmlstudio.top/imgs/others/beauty_3'
					}
				],
				selectShow: false,
				SelectionStatus: false,
				selectionColor: 'black',
				labelShow: false
			}
		},
		methods: {
			icon_choose(title) {
				switch (title) {
					case '标签':
						uni.navigateTo({
							url: '../addLabels/addLabels'
						})
						break;
					case '更多':
						uni.showActionSheet({
							itemList: ['移动至', '下载', '收藏', '删除'],
							success(res) {
								console.log(res)
							},
							fail(res) {
								console.log(res)
							}
						})
				}
			},
			m2allAlbums() {
				uni.navigateTo({
					url: "../allAlbums/allAlbums"
				})
			},
			mediaSelect(e) {
				if (e.currentTarget.dataset.title == '图片')
					this.mediaStatus = 'photo'
				else if (e.currentTarget.dataset.title == '视频') {
					this.mediaStatus = 'video'
					if (this.videos.length == 0) {
						this.empty_status = true
					}
				}
				this.mediaArr.forEach(value => {
					if (value.title == e.currentTarget.dataset.title)
						value.color = '#FF4E28'
					else
						value.color = '#333333'
				})
			},
			lastPage() {
				uni.navigateBack({
					delta: 1
				});
			},
			showSelection() {
				this.SelectionStatus = !this.SelectionStatus
				this.selectionColor = this.selectionColor == 'black' ? '#FF4E28' : 'black'
				this.labelShow = !this.labelShow
			},
			photoSelect() {
				this.photos.forEach(value => {
					value.src_1 = value.src_1 = '../../static/albumsDetail/waitphoto.png'
				})
				this.selectShow = true,
					this.status_1 = 2,
					this.selected_numbers = 0
			},
			videoSelect() {
				this.videos.forEach(value => {
					value.src_1 = value.src_1 = '../../static/albumsDetail/waitphoto.png'
				})
				this.selectShow = true,
					this.status_1 = 2,
					this.selected_numbers = 0
			},
			cancleSelect() {
				this.photos.forEach(value => {
					value.src_1 = value.src_1 = '../../static/albumsDetail/waitphoto.png'
				})
				this.selectShow = false,
					this.status_1 = 1
				this.selected_numbers = 0
			},
			selected(id) {
				let count = 0
				if (id == 'all') {
					if (this.mediaStatus == 'photo') {
						if (this.photos.every(value => {
								return value.src_1 == '../../static/albumsDetail/selected.png'
							})) {
							this.photos.forEach(value => {
								value.src_1 = '../../static/albumsDetail/waitphoto.png'
							})
							count = 0
						} else {
							this.photos.forEach(value => {
								value.src_1 = '../../static/albumsDetail/selected.png'
								if (value.src_1 == '../../static/albumsDetail/selected.png')
									count++
							})
						}
					} else if (this.mediaStatus == 'video') {
						if (this.videos.every(value => {
								return value.src_1 == '../../static/albumsDetail/selected.png'
							})) {
							this.videos.forEach(value => {
								value.src_1 = '../../static/albumsDetail/waitphoto.png'
							})
							count = 0
						} else {
							this.videos.forEach(value => {
								value.src_1 = '../../static/albumsDetail/selected.png'
								if (value.src_1 == '../../static/albumsDetail/selected.png')
									count++
							})
						}
					}
				} else {
					if (this.mediaStatus == 'photo')
						this.photos.forEach(value => {
							if (value.id == id) {
								value.src_1 = value.src_1 == '../../static/albumsDetail/selected.png' ?
									'../../static/albumsDetail/waitphoto.png' : '../../static/albumsDetail/selected.png'
							}
							if (value.src_1 == '../../static/albumsDetail/selected.png')
								count++
						})
					else if (this.mediaStatus == 'video') {
						this.videos.forEach(value => {
							if (value.id == id) {
								value.src_1 = value.src_1 == '../../static/albumsDetail/selected.png' ?
									'../../static/albumsDetail/waitphoto.png' : '../../static/albumsDetail/selected.png'
							}
							if (value.src_1 == '../../static/albumsDetail/selected.png')
								count++
						})
					}
				}
				this.selected_numbers = count
			}
		}
	}
</script>

<style>
	.main {
		display: flex;
		flex-direction: column;
	}

	.bottomTab {
		display: flex;
		position: fixed;
		bottom: -2rpx;
		width: 750rpx;
		height: 96rpx;
		background: rgba(255, 255, 255, 0.9);
		z-index: 1;
	}

	.nav {
		padding-top: 60rpx;
		height: 100rpx;
		font-size: 34upx;
		color: #333333;
		background-color: white;
		position: sticky;
		top: 0;
		left: 0;
		z-index: 1;
	}

	.nav-return {
		width: 35rpx;
		height: 35rpx;
		position: fixed;
		z-index: 1;
	}



	.bottomTab .items {
		height: 96rpx;
		display: flex;
		flex: 1;
		text-align: center;
		flex-direction: column;
	}

	.header {
		width: 750rpx;
		height: 88rpx;
		background: rgb(255, 255, 255);
		display: flex;
		flex-direction: row;
	}

	.header image {
		margin-top: 24rpx;
	}

	.perInfo {
		display: flex;
		flex-direction: column;
		width: 750rpx;
		height: 156rpx;
		background: rgba(255, 255, 255, 1);
		padding: 24rpx;
		border-bottom: 1rpx solid rgba(229, 229, 229, 1);
		;
	}

	.selectTitle {
		display: flex;
		flex-direction: row;
		width: 750rpx;
		height: 100rpx;
		background: rgba(255, 255, 255, 1);
		padding: 30rpx 24rpx;
	}

	.photoArea {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: space-between;
		overflow: auto;
		height: 960rpx;
		align-content: start;
	}

	.photoArea .imgs {
		width: 183rpx;
		height: 183rpx;
		margin-bottom: 6rpx;
		position: relative;

	}

	.header_img {
		width: 40rpx;
		height: 40rpx;
		margin: 0 30rpx;
	}

	.items image {
		width: 48rpx;
		height: 48rpx;
	}

	.photoArea image {
		width: 183rpx;
		height: 183rpx;
	}

	.photoArea video {
		width: 183rpx;
		height: 183rpx;
	}



	.labelPanel {
		z-index: 99;
		position: fixed;
		top: 350rpx;
		left: 230rpx;
		width: 520rpx;
		height: 985rpx;
		background: rgba(255, 255, 255, 1);
	}

	.labels {
		width: 100%;
		height: 890rpx;
		padding: 40rpx;
	}


	.labelPanel text {
		background: rgba(255, 255, 255, 1);
		display: inline-block;
		padding: 8rpx 20rpx;
		width: fit-content;
		height: fit-content;
		background: rgba(255, 243, 240, 1);
		margin-bottom: 32rpx;
		margin-right: 40rpx;
	}

	.labelPanel .btn {
		border-top: 1rpx solid #FF4E28;
		width: 520rpx;
		height: 100rpx;
		text-align: center;
		color: #FF4E28;
		font-size: 32rpx;
		line-height: 100rpx;
	}
</style>
