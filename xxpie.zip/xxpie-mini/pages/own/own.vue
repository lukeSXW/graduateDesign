<template>
	<view class="uni-flex uni-column">
		<view v-if="!isLogin" class="uni-page-body">
			<image src="https://common.xxpie.com/mini-login-bg.png" class="xxp-center xxp-img-login" mode=""></image>
			<button type="primary" class="uni-round uni-w300" @click="login">登录</button>
			<view class="xxp-desc">
				登录查看更多内容
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isLogin: false
			}
		},
		methods: {
			login() {
				uni.navigateTo({
					url: '../login/login',
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style scoped>
.xxp-img-login {
	width: 600rpx;
	height: 600rpx;
	margin: 15% auto;
}
</style>
