<template>
	<view class="uni-page">
		<view class="uni-flex-item">
			<view class="xxp-title">
				<view class="xxp-title-main">享像派</view>
				<view class="xxp-title-desc">
					百万摄影师都在用的APP
				</view>
			</view>
			<view class="xxp-phone uni-inline-item">
				<view class="phone-prev">
					<view class="desc">
						中国
					</view>
					<view class="country-code">
						+86 <view class="angle"></view>
					</view>
				</view>
				<view class="uni-flex-item">
					<input type="text" value="" placeholder="请输入手机号" />
				</view>
			</view>
			<view class="xxp-code uni-inline-item">
				<view class="uni-flex-item">
					<input type="text" value="" placeholder="输入验证码" />
				</view>
				<view class="code-btn">
					获取验证码
				</view>
			</view>
		</view>
		<view class="xxp-footer">
			<button type="primary" class="uni-round uni-w300">登录</button>
			<view class="xxp-login-wx">
				<view class="info">
					<view class="text">
						使用微信登录
					</view>
				</view>
				<image src="https://common.xxpie.com/mini-login-wx.png" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {

		}
	}
</script>

<style scoped>
.xxp-footer {
	padding: 0 32rpx;
}
.xxp-login-wx {
	padding-bottom: 80rpx;
}
.xxp-login-wx .info::before {
	content: "";
	display: block;
	border: 2rpx solid #f2f2f2;
	position: absolute;
	top: 44rpx;
	left: 0;
	right: 0;
}
.xxp-login-wx .info {
	position: relative;
	background-color: #fff;
	text-align: center;
	padding: 20rpx 0;
	height: 100rpx;
}
.xxp-login-wx .info .text {
	position: relative;
	z-index: 9;
	color: #999;
	display: inline-block;
	width: auto;
	padding: 0 24rpx;
	margin-top: -40rpx;
	background-color: #fff;
}
.xxp-login-wx image {
	display: block;
	margin: auto;
	width: 110rpx;
	height: 110rpx;
}
.uni-page > .uni-flex-item {
	padding: 80rpx 32rpx 0 32rpx;
}
.xxp-title-main {
	font-size: 48rpx;
	line-height: 68rpx;
	font-weight: 500;
}
.xxp-title-desc {
	font-size: 26rpx;
	color: #999999;
	line-height: 36rpx;
	margin-bottom: 80rpx;
}
.xxp-phone {
	padding-bottom: 36rpx;
	border-bottom: 2rpx solid #d8d8d8;
}
.xxp-phone .phone-prev {
	width: 150rpx;
	border-right: 2rpx solid #D8D8D8;
}
.xxp-phone .phone-prev .desc {
	font-size: 26rpx;
	color: #999;
}
.xxp-phone .phone-prev .country-code {
	font-size: 34rpx;
}
.xxp-phone .phone-prev .angle {
	display: inline-block;
	border-left: 10rpx solid transparent;
	border-right: 10rpx solid transparent;
	border-top: 12rpx solid #d8d8d8;
	width: 20rpx;
	margin-left: 10rpx;
}
.xxp-phone .uni-flex-item input {
	padding-left: 30rpx;
}
.xxp-code {
	padding: 30rpx 0;
	border-bottom: 2rpx solid #D8D8D8;
}
.xxp-code .uni-flex-item input {
	font-size: 30rpx
}
.xxp-code .code-btn {
	width: 200rpx;
	text-align: right;
	font-size: 34rpx;
}
</style>
