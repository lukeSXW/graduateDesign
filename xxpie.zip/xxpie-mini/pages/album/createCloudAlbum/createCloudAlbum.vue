<template>
	<view class="content">
		<view class="content-v">
			<view class="content-v-l">相册名称</view>
			<view><input type="text" placeholder="给相册取一个名字吧" /></view>
		</view>
		<view class="content-v">
			<view class="content-v-l">相册风格</view>
			<view><input type="text" placeholder="给相册取一个名字吧" /></view>
		</view>
		<view class="content-v">
			<view class="content-v-l">访客上传</view>
			<view><input type="text" placeholder="给相册取一个名字吧" /></view>
		</view>
		<view class="content-v">
			<view class="content-v-l">归属图库</view>
			<view><input type="text" placeholder="给相册取一个名字吧" /></view>
		</view>
	</view>
</template>

<script>
</script>

<style>
	.content{
		margin-top: 20upx;
		flex-wrap: wrap;
		align-content: start;
	}
	.content-v{
		width: 100%;
		margin-left: 24upx;
		padding: 30upx 0upx;
		border-bottom: 1px solid #E5E5E5;
		font-size: 30upx;
		height: 42upx;
		align-items: center;
		
	}
	.content-v-l{
		width: 30%;
	}
</style>
