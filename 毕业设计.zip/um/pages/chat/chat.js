// pages/chat/chat.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatar: '',
    record: [],
    msg:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  
  onLoad: function(options) {
    console.log(options)
    let that = this
    this.setData({
      avatar: options.avatar,
      user_id: options.openid
    })
    wx.request({
      url: 'https://www.htmlstudio.top/chat',
      data: {
        my_id: wx.getStorageSync('openid'),
        star_id: options.openid
      },
      success(res) {
        console.log(res)
        let arr = res.data
        arr.forEach((value, index) => {
          value.msg = Object.values(value)[0]
          if (Object.keys(value)[0] == wx.getStorageSync('openid')) {
            value.avatar = wx.getStorageSync('avatar')
            value.position = 'right'
          } else {
            value.avatar = that.data.avatar
            value.position = 'left'
          }
        })
        that.setData({
          record: arr
        })
      }
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  send: function(event) {
    let that = this
    that.setData({
      msg: ''
    })
    if (!event.detail.value.msg.trim()) {
      wx.showToast({
        title: '不能发送空消息',
        icon: 'none'
      })
    } else {
      wx.request({
        url: 'https://www.htmlstudio.top/send_msg',
        data: {
          star_id: that.data.user_id,
          my_id: wx.getStorageSync('openid'),
          chat_msg: event.detail.value.msg
        },
        success(res) {
          let arr = res.data
          arr.forEach((value, index) => {
            value.msg = Object.values(value)[0]
            if (Object.keys(value)[0] == wx.getStorageSync('openid')) {
              value.avatar = wx.getStorageSync('avatar')
              value.position = 'right'
            } else {
              value.avatar = that.data.avatar
              value.position = 'left'
            }
          })
          that.setData({
            record: arr
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})