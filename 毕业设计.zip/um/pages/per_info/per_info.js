// pages/my_info/my_info.js
Page({

  /**
   * 页面的初始数据
   */

  data: {
    userInfo: {},
    left:25,
    source: [{
      msg: "star",
      imgsrc: 'https://www.htmlstudio.top/imgs/others/star',
      content: '我的关注'
    }, {
      msg: "msg",
      imgsrc: 'https://www.htmlstudio.top/imgs/others/comment',
      content: '我的消息'
    }],
    uid: '未认证',
    ani_1: ''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    if (wx.getStorageSync('uid')) {
      let ani_1 = wx.createAnimation({
        duration: 800,
        timingFunction: 'ease',
        transformOrigin: '50% 50% 0'
      })
      ani_1.opacity(1).step()
      that.setData({
        left:125,
        ani_1: ani_1.export()
      })
      that.setData({
        uid: wx.getStorageSync('uid')
      })
      wx.getUserInfo({
        success(res) {
          that.setData({
            userInfo: JSON.parse(res.rawData)
          })
        }
      })
    } else {
      wx.showToast({
        title: '未登录',
        icon: 'none'
      })
    }
  },


  M2star: function(event) {
    if (event.currentTarget.dataset.msg == "star") {
      wx.navigateTo({
        url: '../stars/stars?msg=star&&id=' + wx.getStorageSync('openid'),
      })
    } else if (event.currentTarget.dataset.msg == "msg"){
      wx.navigateTo({
        url: '../my_msg/my_msg',
      })
    }
  },

  getUserInfo: function(event) {
    console.log(event)
    wx.setStorageSync('nickname', event.detail.userInfo.nickName)
    wx.setStorageSync('avatar', event.detail.userInfo.avatarUrl)
    
    let ani_1 = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease',
      transformOrigin: '50% 50% 0'
    })
    ani_1.opacity(1).step()
    this.setData({
      left: 125,
      ani_1: ani_1.export()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      uid: wx.getStorageSync('uid')
    })
    var that = this;
    wx.getUserInfo({
      success(res) {
        that.setData({
          userInfo: JSON.parse(res.rawData)
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})