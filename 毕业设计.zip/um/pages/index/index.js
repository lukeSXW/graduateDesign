// pages/my_info/my_info.js
const app = getApp()
let QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
let qqmapsdk;
let key = 'F3QBZ-WD7CS-KLBOL-6IZ42-RMFLZ-J7B5R'
const chooseLocation = requirePlugin('chooseLocation');
const referer = '出行助手'; 

Page({
  data: {
    mapHeight: "",
    key: key,
    sex_animation: '',
    per_show: true,
    sex_width: '0rpx',
    panelhidden: false,
    mapSetting: {
      latitude: 27.85632,
      longitude: 112.90737,
      skew: 10,
      rotate: 0,
      showLocation: true,
      showScale: false,
      enableZoom: true,
      enableScroll: true,
      enableRotate: false,
      showCompass: false,
      enable3D: true,
      enableOverlooking: true,
      enableSatellite: false,
      enableTraffic: true,
    },
    position_info: {
      title: '',
      address: '',
      icon_url: 'https://www.htmlstudio.top/imgs/others/router',
    },
    circles: [],
    include_points: [],
    markers: [],
    search_positon: [],
    icon_src: [{
        title: 'friends',
      src: 'https://www.htmlstudio.top/imgs/others/sex',
        right: "15px",
        bottom: "550px",
        animate: '',
        edge: 0
      },
      {
        title: '电影院',
        src: 'https://www.htmlstudio.top/imgs/others/movie',
        right: "15px",
        bottom: "410px",
        animate: '',
        edge: 0
      },
      {
        title: '麦当劳',
        src: 'https://www.htmlstudio.top/imgs/others/eat',
        right: "15px",
        bottom: "360px",
        animate: '',
        edge: 0
      },
      {
        title: '奶茶',
        src: 'https://www.htmlstudio.top/imgs/others/drink',
        right: "15px",
        bottom: "310px",
        animate: '',
        edge: 0
      },
      {
        title: 'weather',
        src: 'https://www.htmlstudio.top/imgs/others/weather',
        right: "15px",
        bottom: "260px",
        animate: '',
        edge: 0
      },
      {
        title: 'self_position',
        src: 'https://www.htmlstudio.top/imgs/others/self_position',
        right: "310px",
        bottom: "260px",
        animate: '',
        edge: 0
      },
    ],
    sex_icons: [{
        title: '只看男生',
      src: 'https://www.htmlstudio.top/imgs/others/boy',
        right: "75px",
        bottom: "550px",
      },
      {
        title: '我全都要',
        src: 'https://www.htmlstudio.top/imgs/others/friends',
        right: "135px",
        bottom: "550px",
      },
      {
        title: '只看女生',
        src: 'https://www.htmlstudio.top/imgs/others/girl',
        right: "195px",
        bottom: "550px",
      }
    ]
  },


  //地点搜索
  position_search: function(location) {
    wx.navigateTo({
      url: 'plugin://chooseLocation/index?key=' + key + '&referer=' + referer
    });
  },


  //地图动画
  map_animate: function(id) {
    let that = this
    let _animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease',
      transformOrigin: '50% 50% 0'
    })
    let arr = that.data.icon_src.map(function(value, index, arr) {
      if (value.title == id) {
        _animation.rotate(value.edge += 180).step()
        value.animate = _animation.export()
      } else {
        value.animate = ''
      }
      return value
    })
    return arr
  },

  //点击地图图标
  icon_tap: function(event) {
    let that = this
    let id = event.currentTarget.id
    let lat = that.data.mapSetting.latitude
    let lng = that.data.mapSetting.longitude
    switch (id) {
      case 'self_position':
        let arr = that.map_animate(id)
        that.setData({
          icon_src: arr,
          mapSetting: {
            latitude: lat,
            longitude: lng
          }
        })
        break;
      case 'weather':
        wx.navigateTo({
          url: '/pages/weather/weather',
        })
        break;
      case 'friends':
        let sex_width = that.data.sex_width
        sex_width = sex_width == '0rpx' ? '90rpx' : '0rpx'
        that.setData({
          sex_width
        })
        let sex_animation = wx.createAnimation({
          duration: 800,
          timingFunction: 'ease',
          transformOrigin: '50% 50% 0'
        })
        sex_animation.width(sex_width).step()
        that.setData({
          sex_animation: sex_animation.export()
        })
        break;
      case '只看男生':
        qqmapsdk.search({
          keyword: '肯德基',
          location: `${lat},${lng}`,
          success: function(res) {
            let marker_arr = res.data
            marker_arr.forEach(function(value, index) {
              value.title = "男生",
                value.latitude = value.location.lat
              value.longitude = value.location.lng
              value.iconPath = 'https://www.htmlstudio.top/imgs/others/boy'
              value.width = 50,
                value.height = 50
            })
            that.setData({
              markers: marker_arr,
              include_points: marker_arr
            })
          }
        })
        break
      case '只看女生':
        qqmapsdk.search({
          keyword: '超市',
          location: `${lat},${lng}`,
          success: function(res) {
            let marker_arr = res.data
            marker_arr.forEach(function(value, index) {
              value.title = "女生",
                value.latitude = value.location.lat
              value.longitude = value.location.lng
              value.iconPath = 'https://www.htmlstudio.top/imgs/others/girl'
              value.width = 50,
                value.height = 50
            })
            that.setData({
              markers: marker_arr,
              include_points: marker_arr
            })
          }
        })
        break
      case '我全都要':
        qqmapsdk.search({
          keyword: '甜品',
          location: `${lat},${lng}`,
          success: function (res) {
            let marker_arr = res.data
            marker_arr.forEach(function (value, index) {
              value.title = "男生",
                value.latitude = value.location.lat
              value.longitude = value.location.lng
              value.iconPath = 'https://www.htmlstudio.top/imgs/others/position'
              value.width = 50,
                value.height = 50
            })
            that.setData({
              markers: marker_arr,
              include_points: marker_arr
            })
          }
        })
        break
      default:
        qqmapsdk.search({
          keyword: id,
          location: `${lat},${lng}`,
          success: function(res) {
            let marker_arr = res.data
            marker_arr.forEach(function(value, index) {
              value.latitude = value.location.lat
              value.longitude = value.location.lng
              value.iconPath = 'https://www.htmlstudio.top/imgs/others/position'
              value.width = 50
              value.height = 50
            })
            that.setData({
              markers: marker_arr,
              include_points: marker_arr
            })
          }
        })
    }
  },



  route_plan: function() {
    let that = this
    let marker_positon = that.data.position_info
    let endPoint = JSON.stringify({
      'name': marker_positon.title,
      'latitude': marker_positon.location.lat,
      'longitude': marker_positon.location.lng
    })
    wx.navigateTo({
      url: 'plugin://routePlan/index?key=' + key + '&referer=' + referer + '&endPoint=' + endPoint
    });
  },

  //地图标记点击函数
  marker_tap: function(e) {
    let that = this
    let marker_item
    let marker_arr = that.data.markers
    marker_arr.forEach(function(value, index) {
      if (value.id == e.markerId)
        marker_item = value
    })

    marker_item.icon_url = 'https://www.htmlstudio.top/imgs/others/router'
    that.setData({
      position_info: marker_item
    })
  },

  // 地图点击函数
  map_tap: function(event) {
    this.setData({
      markers: [],
    })
  },




  onLoad: function(options) {
    let that = this
    wx.getLocation({
      success: function (res) {
        that.setData({
          mapSetting: {
            latitude: res.latitude,
            longitude: res.longitude,
            circles: [{
              latitude: res.latitude,
              longitude: res.longitude,
              fillColor: "#ffffff33",
              radius: 100
            }]
          }
        })
        qqmapsdk.reverseGeocoder({
          latitude: res.latitude,
          longitude: res.longitude,
          success: function (res) {
            console.log(res.result.formatted_addresses.recommend)
            that.setData({
              position_info: {
                title: res.result.formatted_addresses.recommend,
                address: res.result.formatted_addresses.rough,
                icon_url: 'https://www.htmlstudio.top/imgs/others/router',
                location: res.result.ad_info.location,
              },
            })
          }
        })
      },
    })
    qqmapsdk = new QQMapWX({
      key: 'F3QBZ-WD7CS-KLBOL-6IZ42-RMFLZ-J7B5R'
    });
  },


  onReady: function() {

  },


  onShow: function() {
    if (!wx.getStorageSync('login_status')) {
      wx.showModal({
        title: '尊敬的用户',
        content: '请先登录',
        showCancel: false,
        confirmText: '去登陆',
        confirmColor: '#f24f3b',
        success: function () {
          wx.navigateTo({
            url: '../per_regist/per_regist',
          })
        }
      })
    }
    let that = this
    let position_info = {}
    let search_location = chooseLocation.getLocation();
    if (search_location) {
      let position_info = {
        title: search_location.name,
        address:search_location.address,
        icon_url:'https://www.htmlstudio.top/imgs/others/router',
        location: { lat: search_location.latitude, lng: search_location.longitude}
      }
      let arr = [{
        id:1,
        width:50,
        height:50,
        iconPath:'https://www.htmlstudio.top/imgs/others/position',
        latitude: search_location.latitude,
        longitude:search_location.longitude
      }]
      that.setData({
        markers: arr,
        position_info
      })
    }
  },

  onHide: function() {

  },

  onUnload: function() {

  },


  onPullDownRefresh: function() {

  },

  onReachBottom: function() {

  },

  onShareAppMessage: function() {

  }
})