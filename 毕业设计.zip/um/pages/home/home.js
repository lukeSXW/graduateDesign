// pages/home/home.js
Page({
  data: {
    tuijian_ani: '',
    tuijian_opa: 1,
    swiper_images: [],
    animation: '',
    float: 'none',
    publish_src: 'https://www.htmlstudio.top/imgs/others/publish',
    per_message: [],
    inputAnimation: '',
    inputStatus: 1,
    footer: {
      "share": "https://www.htmlstudio.top/imgs/others/share",
      "comment": "https://www.htmlstudio.top/imgs/others/comment",
      "delete_src": "https://www.htmlstudio.top/imgs/others/error"
    }
  },


  onstar: function (event) {
    if (!wx.getStorageSync('uid')) {
      wx.navigateTo({
        url: '../per_regist/per_regist',
      })
    } else {
      if (event.currentTarget.dataset.openid == wx.getStorageSync('openid')) {
        wx.showToast({
          title: '不能关注自己哦',
        })
      } else {
        event.currentTarget.dataset.my_id = wx.getStorageSync('openid')
        wx.request({
          url: 'https://www.htmlstudio.top/onstar',
          data: event.currentTarget.dataset,
          success(res) {
            wx.showToast({
              title: res.data,
            })
          }
        })
      }
    }
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this
    wx.request({
      url: 'https://www.htmlstudio.top/home/home',
      method: 'post',
      success(res) {          
        that.setData({
          per_message: res.data.per_message,
          swiper_images: res.data.swiper_images
        })
      }
    })
  },


   

  // 查看详情函数
  M2detail: function(event) {
    wx.navigateTo({
      url: '../detail_page/detail_page?id=' + event.currentTarget.id
    })
  },

  //评论函数
  comment: function(event) {
    wx.navigateTo({
      url: '../comment_page/comment_page?id=' + event.currentTarget.id
    })
  },

  // 点赞函数
  good_status: function(event) {
    let id = event.currentTarget.id
    let cate = event.currentTarget.dataset.cate
    let per_message = this.data.per_message
    per_message.forEach(value => {
      if (value.id == event.currentTarget.id) {
        value.goodimg = value.goodimg == 'https://www.htmlstudio.top/imgs/others/good' ? 'https://www.htmlstudio.top/imgs/others/good_1' : 'https://www.htmlstudio.top/imgs/others/good'
        if (value.goodimg == 'https://www.htmlstudio.top/imgs/others/good_1') {
          wx.request({
            url: 'https://www.htmlstudio.top/Editgood',
            data:{
              cate:cate,
              id:id,
              add:true
            },
            success(res){
              console.log(res)
            }
          })
          value.good_num += 1
        } else {
          wx.request({
            url: 'https://www.htmlstudio.top/Editgood',
            data: {
              cate: cate,
              id: id,
              add: false
            },
            success(res) {
              console.log(res)
            }
          })
          value.good_num -= 1
        }
      }
    })
    this.setData({
      per_message
    })
  },
  // 标题栏切换函数
  shift: function() {
    let tuijian_opa = this.data.tuijian_opa
    tuijian_opa = tuijian_opa == 0 ? -100 : 0
    let animate = wx.createAnimation({
      duration: 400,
      timingFunction: "linear",
      linear: 0
    })
    animate.opacity(tuijian_opa).step()
    this.setData({
      tuijian_ani: animate.export(),
      tuijian_opa
    })
  },

  //数据提交
  post_msg: function(e) {
    let comment = e.detail.value.comment
    let arr = this.data.per_message
    let animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease',
      transformOrigin: '50% 50% 0'
    })
    animation.scale(0.01).step()
    this.setData({
      per_message: arr,
      inputAnimation: animation.export(),
      inputStatus: 0.01
    })
  },
  // 显示输入框函数
  showInput: function() {
    let status = this.data.inputStatus
    status = status == 1 ? 0.01 : 1
    this.setData({
      inputStatus: status
    })
    let animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease',
      transformOrigin: '50% 50% 0'
    })
    animation.scale(status).step()
    this.setData({
      inputAnimation: animation.export()
    })
  },

  // 删除信息函数
  delete_msg: function(event) {
    let that = this
    let index = event.currentTarget.id
    let msg_arr = this.data.per_message.filter(item => {
      return item.id != index
    })

    that.setData({
      per_message: msg_arr
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this
    wx.request({
      url: 'https://www.htmlstudio.top/home/home',
      method: 'post',
      success(res) {
        that.setData({
          per_message: res.data.per_message,
          swiper_images: res.data.swiper_images
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})